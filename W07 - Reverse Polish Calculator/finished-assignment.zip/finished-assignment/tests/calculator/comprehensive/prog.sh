#!/bin/bash
./CalculatorMain

