#!/bin/bash
make CalculatorMain
