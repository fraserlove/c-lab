#!/bin/bash

# The 'true' makes sure we don't stop because
# the 'make clean' produced an error
make clean; true

