#!/bin/bash
ulimit -t 300

./TestStack
