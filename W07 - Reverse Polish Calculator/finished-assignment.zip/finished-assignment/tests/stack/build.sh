#!/bin/bash
make TestStack
