## Compilation

Within the ./src directory the program can be compiled using:

    make

The stack can be tested with:
    
    ./TestStack

The RPN calculator can be ran with:

    ./CalculatorMain

Then simply enter the expression in reverse polish notation and press enter.
