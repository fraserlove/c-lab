
long long fibcalc(long long n);