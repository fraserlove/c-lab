
long long safe_add(long long a, long long b);