#include "print_fib.h"

int main() {
    print_fib();
    return 0;
}